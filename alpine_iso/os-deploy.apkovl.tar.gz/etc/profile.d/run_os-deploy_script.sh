#!/bin/sh
sh <(curl -s http://10.25.0.54:8000/scripts/start.sh)
