#!/bin/sh
sh <(curl -s http://osdeploy.internal:8000/scripts/start.sh)
